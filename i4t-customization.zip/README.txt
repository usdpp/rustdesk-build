i4t.com RustDesk 个性化配置包
方案：我的 RustDesk 客户端
方案 ID：4d1ff7ee-0415-4380-8afd-3b96445ccd47

未上传 Logo 或软件图标时，构建会自动使用 RustDesk-on 源码内置的默认图片。

1. 使用模板创建你自己的仓库：https://github.com/abcdocker/rustdesk-custom-builder-template/generate
2. 将本文件所在的 i4t-customization.zip 原样上传到仓库根目录。
3. 打开 Actions，运行 Build customized client。
4. 在运行结果的 Artifacts 或 Release 下载客户端。

本包不包含代码签名私钥、GitHub Token 或代理配置。服务器 Key 是公开密钥，不是服务器私钥。
源码：https://github.com/abcdocker/RustDesk-on
许可证：AGPL-3.0
